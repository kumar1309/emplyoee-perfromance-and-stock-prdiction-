import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart'; // For file handling
import 'dart:io'; // For file creation
import 'app_drawer.dart'; // Import your AppDrawer

class BillingPage extends StatefulWidget {
  final String username;

  const BillingPage({super.key, required this.username});

  @override
  _BillingPageState createState() => _BillingPageState();
}

class _BillingPageState extends State<BillingPage> {
  Future<void> _downloadInvoice(String invoiceNumber) async {
    try {
      // Get the directory to save the file
      final directory = await getApplicationDocumentsDirectory();
      final path = '${directory.path}/$invoiceNumber.pdf';
      final file = File(path);

      // Simulate downloading the invoice
      await file.writeAsString('Invoice Data for $invoiceNumber');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Invoice downloaded to $path'),
      ));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error downloading invoice: $e'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Billing',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
          ),
        ),
        backgroundColor: Colors.blue,
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
      ),
      drawer: AppDrawer(
        // Ensure the sidebar is added
        username: widget.username,
        isDarkMode: false, // Set dark mode state as needed
        toggleTheme: () {}, // Implement toggle theme function if needed
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Billing Information for ${widget.username}',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Payment History:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 10),
            ListTile(
              title: const Text('Invoice #12345'),
              subtitle: const Text('Date: 01/10/2024 - Amount: \$100'),
              trailing: IconButton(
                icon: const Icon(Icons.download),
                onPressed: () => _downloadInvoice('12345'), // Trigger download
              ),
            ),
            ListTile(
              title: const Text('Invoice #12346'),
              subtitle: const Text('Date: 01/11/2024 - Amount: \$120'),
              trailing: IconButton(
                icon: const Icon(Icons.download),
                onPressed: () => _downloadInvoice('12346'), // Trigger download
              ),
            ),
            // Add more billing entries as needed
          ],
        ),
      ),
    );
  }
}
