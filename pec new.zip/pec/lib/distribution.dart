import 'package:flutter/material.dart';
import 'app_drawer.dart';

class DistributionPage extends StatefulWidget {
  const DistributionPage({super.key});

  @override
  _DistributionPageState createState() => _DistributionPageState();
}

class _DistributionPageState extends State<DistributionPage> {
  bool _isDarkMode = false;

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Distribution'),
      ),
      drawer: AppDrawer(
        username: 'Username',
        isDarkMode: _isDarkMode,
        toggleTheme: _toggleTheme,
      ),
      body: const Center(
        child: Text('This is the Distribution Page'),
      ),
    );
  }
}
