import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart'; // Import Firebase Database
import 'app_drawer.dart';

class Item {
  final String name;
  final int present;
  final List<MapEntry<String, int>> lastSevenDates; // Store date-value pairs

  Item({
    required this.name,
    required this.present,
    required this.lastSevenDates,
  });

  // Factory method to create an Item object from a Firebase snapshot
  factory Item.fromJson(String name, Map<dynamic, dynamic> data) {
    final dates = data.entries
        .where((entry) => entry.key != 'present') // Exclude the 'present' field
        .map((entry) => MapEntry(entry.key as String, entry.value as int))
        .toList();

    // Sort by date (key)
    dates.sort((a, b) => b.key.compareTo(a.key)); // Sort descending

    // Get the last seven dates
    final lastSeven = dates.take(7).toList();

    return Item(
      name: name,
      present: data['present'] ?? 0,
      lastSevenDates: lastSeven,
    );
  }
}

class ItemsPage extends StatefulWidget {
  const ItemsPage({super.key});

  @override
  _ItemsPageState createState() => _ItemsPageState();
}

class _ItemsPageState extends State<ItemsPage> {
  bool _isDarkMode = false;
  String _searchQuery = "";
  List<Item> _items = []; // List to hold items fetched from Firebase
  DatabaseReference? _databaseRef; // Reference to the Firebase Database
  List<bool> _expandedItems = []; // Track which items are expanded

  @override
  void initState() {
    super.initState();
    _databaseRef = FirebaseDatabase.instance.ref().child('storages/storage1/items'); // Reference to the 'items' node
    _fetchItems();
  }

  // Function to fetch items from Firebase and update the _items list
  Future<void> _fetchItems() async {
    final snapshot = await _databaseRef!.get();

    if (snapshot.exists) {
      List<Item> itemsList = [];

      // Cast the snapshot value to Map<dynamic, dynamic> before using forEach
      final itemsMap = snapshot.value as Map<dynamic, dynamic>;

      itemsMap.forEach((key, value) {
        itemsList.add(Item.fromJson(key, value));
      });

      setState(() {
        _items = itemsList;
        _expandedItems = List.filled(_items.length, false); // Initialize expanded items list
      });
    }
  }

  // Method to filter items based on the search query
  List<Item> _filteredItems() {
    if (_searchQuery.isEmpty) {
      return _items;
    }
    return _items
        .where((item) => item.name.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();
  }

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Items'),
      ),
      drawer: AppDrawer(
        username: 'Username',
        isDarkMode: _isDarkMode,
        toggleTheme: _toggleTheme,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            // Search Bar
            TextField(
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
              decoration: InputDecoration(
                labelText: 'Search',
                border: OutlineInputBorder(),
                prefixIcon: const Icon(Icons.search),
              ),
            ),
            const SizedBox(height: 16),
            // Display items in a GridView
            Expanded(
              child: _items.isEmpty
                  ? const Center(child: CircularProgressIndicator()) // Show a loading indicator if items are not yet loaded
                  : GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2, // Adjust number of columns as needed
                        childAspectRatio: 1.2, // Aspect ratio for item cards (reduced size)
                        mainAxisSpacing: 12,
                        crossAxisSpacing: 12,
                      ),
                      itemCount: _filteredItems().length,
                      itemBuilder: (context, index) {
                        final item = _filteredItems()[index];
                        return _buildItemCard(item, index);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // Function to build each item card
  Widget _buildItemCard(Item item, int index) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _expandedItems[index] = !_expandedItems[index]; // Toggle expansion state
        });
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        elevation: 5,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              item.name,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Available: ${item.present}', // Display the 'present' count
              style: const TextStyle(
                fontSize: 16,
                color: Colors.green,
              ),
            ),
            if (_expandedItems[index]) // Show last seven dates when the card is expanded
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: item.lastSevenDates.map((entry) {
                    return Text(
                      '${entry.key}: ${entry.value}', // Display date and value
                      style: const TextStyle(fontSize: 14),
                    );
                  }).toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
