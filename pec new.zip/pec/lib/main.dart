import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dashboard.dart'; // Import the dashboard file
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart'; // Import Firebase Database

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyBGhbORn0cl-9L5cIBHO6IwqN_VzH5gGWY",
            authDomain: "sparkathon-ee76f.firebaseapp.com",
            databaseURL: "https://sparkathon-ee76f-default-rtdb.firebaseio.com",
            projectId: "sparkathon-ee76f",
            storageBucket: "sparkathon-ee76f.appspot.com",
            messagingSenderId: "727829521805",
            appId: "1:727829521805:web:21f0fa770575dfac5949c4",
            measurementId: "G-6H8673T569"));
  } else {
    await Firebase.initializeApp();
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login Demo',
      theme: ThemeData(
        colorScheme:
            ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 0, 0, 0)),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Login Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final _formKey = GlobalKey<FormState>();
  String _username = '';
  String _password = '';

  DatabaseReference? _databaseRef; // Firebase Database reference
  final Map<dynamic, dynamic> _firebaseData = {}; // To store Firebase data

  @override
  void initState() {
    super.initState();
    _databaseRef =
        FirebaseDatabase.instance.ref().child('users'); // Correct method here
  }

  // Login logic
  Future<void> _login() async {
    if (_formKey.currentState!.validate()) {
      // Fetch data for the given username
      final snapshot = await _databaseRef!.child(_username).get();

      if (snapshot.exists) {
        // Check if the password matches
        final userData = snapshot.value as Map<dynamic, dynamic>;
        if (userData['password'] == _password) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DashboardPage(username: _username),
            ),
          );
        } else {
          _showError('Invalid username or password');
        }
      } else {
        _showError('User not found');
      }
    }
  }

  // Function to show error
  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(
          widget.title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: 'Username'),
                onChanged: (value) {
                  _username = value;
                },
                validator: (value) {
                  return value!.isEmpty ? 'Please enter your username' : null;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true,
                onChanged: (value) {
                  _password = value;
                },
                validator: (value) {
                  return value!.isEmpty ? 'Please enter your password' : null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _login,
                child: const Text('Login'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
