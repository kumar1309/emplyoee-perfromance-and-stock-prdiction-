import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fl_chart/fl_chart.dart';

class PredictorPage extends StatefulWidget {
  const PredictorPage({super.key});

  @override
  _PredictorPageState createState() => _PredictorPageState();
}

class _PredictorPageState extends State<PredictorPage> {
  final TextEditingController _itemController = TextEditingController();
  final TextEditingController _storageController = TextEditingController();
  String _result = '';
  List<double> _predictedSales = [];
  bool _showChart = false;

  Future<void> _predict() async {
    final String itemName = _itemController.text;
    final String storageName = _storageController.text;

    if (itemName.isEmpty || storageName.isEmpty) {
      setState(() {
        _result = "Please enter both item and storage names.";
      });
      return;
    }

    final url = Uri.parse('http://127.0.0.1:5000/calculate'); // Replace with your Flask server IP
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'item': itemName,
        'storage': storageName,
      }),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      setState(() {
        if (data['date'] != null) {
          _result = "Predicted run-out date: ${data['date']}";
          _predictedSales = List<double>.from(data['values']);
          _showChart = true;
        } else {
          _result = data['error'];
          _showChart = false;
        }
      });
    } else {
      setState(() {
        _result = "Error: ${response.body}";
        _showChart = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventory Predictor'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _itemController,
              decoration: const InputDecoration(
                labelText: 'Item Name',
              ),
            ),
            TextField(
              controller: _storageController,
              decoration: const InputDecoration(
                labelText: 'Storage Name',
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _predict,
              child: const Text('Predict Run-Out Date'),
            ),
            const SizedBox(height: 20),
            Text(
              _result,
              style: const TextStyle(fontSize: 16, color: Colors.blue),
            ),
            const SizedBox(height: 20),
            _showChart
                ? SizedBox(
                    height: 300,
                    child: LineChart(
                      LineChartData(
                        titlesData: FlTitlesData(
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (value, meta) {
                                return Text(value.toInt().toString());
                              },
                            ),
                          ),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (value, meta) {
                                return Text(value.toInt().toString());
                              },
                            ),
                          ),
                        ),
                        borderData: FlBorderData(show: true),
                        lineBarsData: [
                          LineChartBarData(
                            spots: _predictedSales.asMap().entries.map((entry) {
                              return FlSpot(entry.key.toDouble(), entry.value);
                            }).toList(),
                            isCurved: true,
                            gradient: LinearGradient(
                              colors: [Colors.blue, Colors.green],
                            ),
                            barWidth: 4,
                            isStrokeCapRound: true,
                            belowBarData: BarAreaData(
                              show: true,
                              gradient: LinearGradient(
                                colors: [
                                  Colors.blue.withOpacity(0.3),
                                  Colors.green.withOpacity(0.3)
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                : Container(),
          ],
        ),
      ),
    );
  }
}
