import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'app_drawer.dart';

class DashboardPage extends StatefulWidget {
  final String username;

  const DashboardPage({super.key, required this.username});

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  bool _isDarkMode = false;
  DatabaseReference? _databaseRef;
  Map<dynamic, dynamic>? _userData;

  @override
  void initState() {
    super.initState();
    _databaseRef =FirebaseDatabase.instance.ref().child('users/${widget.username}');
    _fetchUserData();
  }

  // Fetch user data from Firebase
  Future<void> _fetchUserData() async {
    final snapshot = await _databaseRef!.get();
    if (snapshot.exists) {
      setState(() {
        _userData = snapshot.value as Map<dynamic, dynamic>?;
      });
    } else {
      print('No data available for user: ${widget.username}');
    }
  }

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Dashboard',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
          ),
        ),
        backgroundColor: _isDarkMode ? Colors.grey[900] : Colors.blue,
        iconTheme: IconThemeData(
          color: _isDarkMode ? Colors.white : Colors.white,
        ),
      ),
      drawer: AppDrawer(
        username: widget.username,
        isDarkMode: _isDarkMode,
        toggleTheme: _toggleTheme,
      ),
      body: _userData == null
          ? const Center(
              child:
                  CircularProgressIndicator()) // Show loader while data is loading
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome to your dashboard, ${widget.username}!',
                    style: TextStyle(
                      fontSize: 24,
                      color: _isDarkMode ? Colors.white : Colors.black,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Name: ${_userData?['name'] ?? 'N/A'}',
                    style: TextStyle(
                      fontSize: 18,
                      color: _isDarkMode ? Colors.white : Colors.black,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Performance 1: ${_userData?['performance1'] ?? 'N/A'}',
                    style: TextStyle(
                      fontSize: 16,
                      color: _isDarkMode ? Colors.white : Colors.black,
                    ),
                  ),
                  Text(
                    'Performance 2: ${_userData?['performance2'] ?? 'N/A'}',
                    style: TextStyle(
                      fontSize: 16,
                      color: _isDarkMode ? Colors.white : Colors.black,
                    ),
                  ),
                  Text(
                    'Performance 3: ${_userData?['performance3'] ?? 'N/A'}',
                    style: TextStyle(
                      fontSize: 16,
                      color: _isDarkMode ? Colors.white : Colors.black,
                    ),
                  ),
                  Text(
                    'Performance 4: ${_userData?['performance4'] ?? 'N/A'}',
                    style: TextStyle(
                      fontSize: 16,
                      color: _isDarkMode ? Colors.white : Colors.black,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Hike: ${_userData?['hike'] ?? 'N/A'}',
                    style: TextStyle(
                      fontSize: 18,
                      color: _isDarkMode ? Colors.white : Colors.black,
                    ),
                  ),
                ],
              ),
            ),
      backgroundColor: _isDarkMode ? Colors.black : Colors.white,
    );
  }
}
