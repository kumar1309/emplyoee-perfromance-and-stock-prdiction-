package com.example.pec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
